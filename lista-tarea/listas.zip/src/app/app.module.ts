import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { TaskListComponentTsComponent } from './task-list.component.ts/task-list.component.ts.component';
import { AddListComponentTsComponent } from './add-list.component.ts/add-list.component';
import { TaskComponentTsComponent } from './task.component.ts/task.component.ts.component';

@NgModule({
  declarations: [
    AppComponent,
    TaskListComponentTsComponent,
    AddListComponentTsComponent,
    TaskComponentTsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
