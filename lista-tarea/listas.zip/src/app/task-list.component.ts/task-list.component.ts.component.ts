// src/app/task-list.component.ts
import { Component } from '@angular/core';
import { Task } from './task.interface';



@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent {
  tasks: Task[] = [];
}

// src/app/add-task.component.ts
import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent {
  @Output() addTask = new EventEmitter<string>();

  add(name: string) {
    this.addTask.emit(name);
  }
}


import { Component, Input } from '@angular/core';
import { Task } from './task.interface';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent {
  @Input() task: Task;

  complete() {
    this.task.completed = true;
  }
}
