import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TaskListComponentTsComponent } from '../components/task-list.component.ts.component';


describe('TaskListComponentTsComponent', () => {
  let component: TaskListComponentTsComponent;
  let fixture: ComponentFixture<TaskListComponentTsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TaskListComponentTsComponent]
    });
    fixture = TestBed.createComponent(TaskListComponentTsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
