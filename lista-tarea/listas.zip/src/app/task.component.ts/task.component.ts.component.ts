// src/app/task.component.ts
import { Component, Input } from '@angular/core';
import { Task } from '../task.interface';


@Component({
  selector: 'app-task',
  templateUrl: '../task-list/task-list.component.html',


  styleUrls: ['./task.component.css']
})
export class TaskComponent {
  @Input() task: Task;

  complete() {
    this.task.completed = true;
  }
}
