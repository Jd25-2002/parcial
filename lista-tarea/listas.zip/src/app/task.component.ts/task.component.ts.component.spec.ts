import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskComponentTsComponent } from './task.component.ts.component';

describe('TaskComponentTsComponent', () => {
  let component: TaskComponentTsComponent;
  let fixture: ComponentFixture<TaskComponentTsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TaskComponentTsComponent]
    });
    fixture = TestBed.createComponent(TaskComponentTsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
