import { Component } from '@angular/core';

@Component({
  selector: 'app-add-list.component.ts',
  templateUrl: './add-list.component.ts.component.html',
  styleUrls: ['./add-list.component.ts.component.css']
})
export class AddListComponentTsComponent {

}
