import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddListComponentTsComponent } from './add-list.component';

describe('AddListComponentTsComponent', () => {
  let component: AddListComponentTsComponent;
  let fixture: ComponentFixture<AddListComponentTsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddListComponentTsComponent]
    });
    fixture = TestBed.createComponent(AddListComponentTsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
